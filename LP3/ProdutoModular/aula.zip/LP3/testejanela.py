import tkinter as tk

def responde_butao():
    rotulo.config(text="Você clicou no butão")

janela = tk.Tk()
janela.title("Olá")
rotulo = tk.Label(janela, text="Clique no Butãozinho")
rotulo.pack(pady=20)
janela.geometry("420x420")

butao = tk.Button(janela, text="Butão", command=responde_butao)
butao.pack(pady=50)

janela.mainloop()